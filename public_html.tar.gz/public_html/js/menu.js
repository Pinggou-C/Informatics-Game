class Menu extends Phaser.Scene {
    constructor() {
        super('Menu');
    }
    preload()
    {
    	//load our images or sounds
    }
    create() {
       //define our objects
       console.log("Ready!");
    }
    update() {
        //constant running loop
    }

}
