# Informatics-Game
This is the game project for informatics
