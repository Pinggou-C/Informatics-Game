<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="main.css"/>
    <title>main</title>
    <script type="text/javascript">
	function loading(){
		if (typeof(Storage) !== "undefined") {
			if (localStorage.getItem("lastname") !== null){
			switchh(localStorage.getItem("lastname"));
			}
			else{
				localStorage.setItem("lastname", 1);
				switchh(localStorage.getItem("lastname"));}
			}
		else{
			window.alert("Sorry, your browser does not support Web Storage...");
			}

	}
    function switchh(indexx = 1){
		localStorage.setItem("lastname", indexx);
		var divsToHide = document.getElementsByClassName("insidemain");
		for(var i = 0; i < divsToHide.length; i++){
			divsToHide[i].style.display = "none";
		}
		var hello = 'e' + indexx;
		document.getElementById(hello).style.display = "block";
	}
    function myFunction() {
		document.getElementById("frm1").submit();
    }
  </script>
  </head>
  <body onload="loading();">
  <header id="head">
    <div id="inbar">
    <button onclick="switchh(1)" class="infi" onclick="switchh(1)">Home</button>
    </div>
  </header>
    <nav>
      <div class="segment">
        <button class="infi" name="info" onclick="switchh(1)">Home</button>
          <div class="dropdown-content">
            <button class="btnBlue"onclick="switchh(1)">This website</button>
          </div>
      </div>
      <div class="segment">
        <button class="infi" name="info" onclick="switchh(2)">About us</button>
        <div class="dropdown-content">
          <button class="btnBlue"  onclick="switchh(2)">Who am I</button>
          </br>
          <button class="btnBlue"onclick="switchh(2)">What I do</button>
          </br>
          <button class="btnBlue"onclick="switchh(2)">this sdfd dsfsvsdswebsite</button>
        </div>
      </div>
      <div class="segment">
        <button class="infi" name="info" onclick="switchh(3)">Things I Guess</button>
        <div class="dropdown-content">
          <button class="btnBlue"onclick="switchh(3)">Data form</button>
          </br>
          <button class="btnBlue"onclick="switchh(3)">friasdfadends</button>
        </div>
      </div>
      <div class="segment">
        <button class="infi" name="info" onclick="switchh(4)">More Thing</button>
        <div class="dropdown-content">
          <button class="btnBlue"onclick="switchh(4)">db</button>
          </br>
          <button class="btnBlue"onclick="switchh(4)">friesfdfgvnds</button>
          </br>
          <button class="btnBlue"onclick="switchh(4)">this wecvdfxcvbsite</button>
          </br>
          <button class="btnBlue"onclick="switchh(4)">friesfdfgvnds</button>
          </br>
          <button class="btnBlue"onclick="switchh(4)">this wecvdfxcvbsite</button>
          </div>
      </div>
      <div class="segment">
        <button class="infi" name="info" onclick="switchh(5)">And EVEN More</button>
        <div class="dropdown-content">
          <button class="btnBlue"onclick="switchh(5)">mfzde</button>
          </br>
          <button class="btnBlue"onclick="switchh(5)">frienzdffbfdxds</button>
          </br>
          <button class="btnBlue" onclick="switchh(5)">this websixdfbxdte</button>
          </br>
          <button class="btnBlue" onclick="switchh(5)">this websixdfbxdte</button>
        </div>
      </div>
    </nav>
    <main>
      <div class="insidemain" id="e1">
        <div class="topinbar">
          Hello There
        </div>

        <div style="width: 100%;position: relative;"><iframe width="100%" height="250px" src="https://maps.google.com/maps?width=250&amp;height=640&amp;hl=en&amp;q=Amsterdam%2C%20Nederland+(Titel)&amp;ie=UTF8&amp;t=&amp;z=10&amp;iwloc=B&amp;output=embed" frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe><div style="position: absolute;width: 80%;left: 0;right: 0;margin-left: auto;margin-right: auto;color: #000;text-align: center;"><small style="line-height: 1.8;font-size: 2px;background: #fff;">Powered by <a href="http://www.googlemapsgenerator.com/zh/">gmapgen zh</a> & <a href="https://isitvivid.com/the-ethical-question-of-buying-web-traffic-for-business/">diabolic traffic bot</a></small></div><style>#gmap_canvas img{max-width:none!important;background:none!important}</style></div><br />
      </div>
      <div class="insidemain" id="e2">
		  <h1 id="result"></h1>
        <div id="ininsidemain">
          <div class="topinbar">
            I Am Milo
          </div>
        </div>
        <div class="ininsidemain2">
          <div class="topinbar">
            Well, I Like Programming
            <table style="width:100%" style="border:2px solid black" style="border-radius: 25px">
              <tr>
                <th>d</th>
                <th>d</th>
                <th>d</th>
                <th>d</th>
                <th>d</th>
              </tr>
              <tr>
                <th>d</th>
                <th>d</th>
                <th>d</th>
                <th>d</th>
                <th>d</th>
              </tr>


            </table>
          </div>
        </div>
        <div class="ininsidemain2">
          <div class="topinbar">
            I Also Like Other Things Tho
          </div>
        </div>
      </div>
      <div class="insidemain" id="e3">
        <div class="ininsidemain3" id="top">
          <div class="topinbar">
            Data Form(I Had To Put This In The Site)
          </div>
          

        </div>
        <div class="ininsidemain3" id="bot">
          <div class="topinbar">
            This Too(I Had To Make This Website As A School Project)
          </div>
          <ul>
            <li>Hello  </li>
            <li>I   </li>
            <li>Am  </li>
            <li>Milo  </li>
            <li>And  </li>
            <li>Who  </li>
            <li>Are  </li>
            <li>You?  </li>
          </ul>

        </div>
      </div>
      <div class="insidemain" id="e4">
        <div class="ininsidemain4" id="left">
          <div class="topinbar">
            Not The Greatest
          </div>
                    <?php
$name = $email = $gender = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $name = test_input($_POST["name"]);
  $email = test_input($_POST["email"]);
  $gender = test_input($_POST["gender"]);
}

function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
?>


<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
  Name: <input type="text" name="name">
  <br><br>
  E-mail: <input type="text" name="email">
  <br><br>
  Gender:
  <input type="radio" name="gender" value="female">Female
  <input type="radio" name="gender" value="male">Male
  <input type="radio" name="gender" value="other">Other
  <br><br>
  <input type="submit" name="submit" value="Submit">
</form>

<?php
echo "<h2>Your Input:</h2>";
echo $name;
echo "<br>";
echo $email;
echo "<br>";
echo $gender;
?>
        </div>
        <div class="ininsidemain4">
          <div class="topinbar">
            Of Reasons
          </div>
        </div>
        <div class="ininsidemain4">
          <div class="topinbar">
            But Since I Like
          </div>
        </div>
        <div class="ininsidemain4">
          <div class="topinbar">
            Programming It's
          </div>

        </div>
        <div class="ininsidemain4">
          <div class="topinbar">
             Okey
          </div>
        </div>
      </div>
      <div class="insidemain" id="e5">
        <div class="ininsidemain5" id="leftop">
          <div class="topinbar">
            This Not My Original Site
          </div>
        </div>
        <div class="ininsidemain5" id="topp">
          <div class="topinbar">
            That One Contained Puzzles And Games Alike
          </div>
        </div>
        <div class="ininsidemain5" id="left">
          <div class="topinbar">
            But I Stopped With The Games In JavaScript
          </div>
        </div>
        <div class="ininsidemain5">
          <div class="topinbar">
            But I Still Make Them, Just With Other Tools
          </div>
        </div>
      </div>
    </main>

  </body>
  
</html>
